package com.example.trashoclock.ui.home

import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.trashoclock.R
import com.example.trashoclock.ui.components.StatusBarIcons
import com.example.trashoclock.ui.components.card
import com.example.trashoclock.ui.components.showComingSoon
import com.example.trashoclock.ui.theme.ChipGreen
import com.example.trashoclock.ui.theme.FieldBorder
import com.example.trashoclock.ui.theme.Green
import com.example.trashoclock.ui.theme.HeaderGreen
import com.example.trashoclock.ui.theme.Ink
import com.example.trashoclock.ui.theme.PaleGreen
import com.example.trashoclock.ui.theme.ScheduleLine
import com.example.trashoclock.ui.theme.Scrim
import com.example.trashoclock.ui.theme.SplashGradientBottom
import com.example.trashoclock.ui.theme.SplashGradientMid
import com.example.trashoclock.ui.theme.SplashGradientTop
import com.example.trashoclock.ui.theme.TextMuted
import com.example.trashoclock.ui.theme.TrashOClockTheme
import com.example.trashoclock.ui.theme.poppins
import java.time.LocalDate

/**
 * 08 Home. [contentPadding] reserves space for the bottom nav bar drawn by the parent.
 * The announcement popup (08c) covers only this content, leaving the nav bar visible.
 * [today] is the phone's current date; tests pass a fixed one.
 */
@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
    today: LocalDate = LocalDate.now(),
) {
    StatusBarIcons(dark = false)
    val context = LocalContext.current
    var droppedOff by rememberSaveable { mutableStateOf(false) }
    var showAnnouncement by rememberSaveable { mutableStateOf(false) }

    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(0f to SplashGradientTop, 0.5f to SplashGradientMid, 1f to SplashGradientBottom))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(contentPadding)
        ) {
            Header(onSettings = { showComingSoon(context) })
            Spacer(Modifier.height(10.dp))
            ReminderCard(droppedOff = droppedOff, onDone = { droppedOff = true })
            SectionTitle(R.drawable.img_megaphone, "ANNOUNCEMENT", iconSize = 51.66.dp, iconStart = 16.dp, titleStart = 62.dp, titleTop = 12.dp, iconRotation = -0.94f)
            AnnouncementCard(onClick = { showAnnouncement = true })
            SectionTitle(R.drawable.img_schedule, "SCHEDULE", iconSize = 48.dp, iconStart = 13.dp, titleStart = 65.dp, titleTop = 15.dp)
            ScheduleCard(today = today, onPickUpClick = { showComingSoon(context) })
            Spacer(Modifier.height(10.dp))
        }

        if (showAnnouncement) {
            AnnouncementPopup(
                onDismiss = { showAnnouncement = false },
                modifier = Modifier.padding(bottom = contentPadding.calculateBottomPadding())
            )
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(104.dp)
            .background(HeaderGreen, RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
    ) {
        Image(painterResource(R.drawable.ic_location), contentDescription = null, modifier = Modifier.offset(20.dp, 50.dp))
        Column(Modifier.offset(46.dp, 46.dp)) {
            Text("123 Street", style = poppins(16, FontWeight.Bold), color = PaleGreen)
            Text("City, Province", style = poppins(13), color = PaleGreen, modifier = Modifier.offset(y = (-4).dp))
        }
        Image(
            painter = painterResource(R.drawable.ic_settings),
            contentDescription = "Settings",
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-20).dp, y = 44.dp)
                .clip(RoundedCornerShape(22.dp))
                .clickable(onClick = onSettings)
        )
    }
}

/** 08 "Drop off your trash today!" / 08b "Trash dropped off". */
@Composable
private fun ReminderCard(droppedOff: Boolean, onDone: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(96.dp)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .card(radius = 22.dp, shadowBlur = 7.dp)
        ) {
            if (droppedOff) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(start = 17.dp, top = 31.dp)
                ) {
                    Text("Trash dropped off", style = poppins(22, FontWeight.Bold), color = Ink)
                    Image(painterResource(R.drawable.ic_check_circle), contentDescription = null)
                }
            } else {
                Text(
                    "Drop off your  trash today!",
                    style = poppins(21, FontWeight.Bold).copy(lineHeight = 25.sp),
                    color = Ink,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.padding(start = 14.dp, top = 21.dp)
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = 50.dp)
                        .size(width = 84.dp, height = 28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Green)
                        .clickable(onClick = onDone)
                ) {
                    Text("Done", style = poppins(13, FontWeight.Medium), color = Color.White)
                }
            }
        }
        // The bag photo hangs 15dp past the card's right edge
        Image(
            painter = painterResource(R.drawable.img_trash_bag),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 15.dp, y = if (droppedOff) 0.dp else (-1).dp)
                .size(98.dp)
                .clip(RoundedCornerShape(44.dp))
        )
    }
}

/** Icon + bold heading in the 42dp gap between cards. */
@Composable
private fun SectionTitle(
    @DrawableRes icon: Int,
    title: String,
    iconSize: Dp,
    iconStart: Dp,
    titleStart: Dp,
    titleTop: Dp,
    iconRotation: Float = 0f,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(42.dp)
    ) {
        Image(
            painter = painterResource(icon),
            contentDescription = null,
            modifier = Modifier
                .offset(x = iconStart)
                .size(iconSize)
                .rotate(iconRotation)
        )
        Text(title, style = poppins(18, FontWeight.Bold), color = Ink, modifier = Modifier.offset(titleStart, titleTop))
    }
}

@Composable
private fun AnnouncementCard(onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(120.dp)
            .card(radius = 22.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(top = 5.dp)
    ) {
        Text("Delay in Garbage Collection for next week", style = poppins(12, FontWeight.Bold).copy(fontSize = 12.5.sp), color = Ink)
        Text("due to: Typhoon Pepito", style = poppins(11), color = Ink)
        Spacer(Modifier.height(2.dp))
        Image(painterResource(R.drawable.img_typhoon_small), contentDescription = null)
        Text("View more ⌄", style = poppins(11, FontWeight.Medium), color = Ink)
    }
}

@Composable
private fun ScheduleCard(today: LocalDate, onPickUpClick: () -> Unit) {
    // The tapped day, stored as a day number so it survives rotation; starts on today.
    // Keyed on today so it resets if the app is still open when the date changes.
    var selectedDay by rememberSaveable(today) { mutableStateOf(today.toEpochDay()) }
    val selected = LocalDate.ofEpochDay(selectedDay)
    val pickUps = pickUpsOn(selected)

    Box(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(340.dp)
            .card(radius = 22.dp)
            .clip(RoundedCornerShape(22.dp))
    ) {
        Text(fullDate(selected), style = poppins(12), color = TextMuted, modifier = Modifier.offset(21.dp, 11.dp))
        Text(dayTitle(selected, today), style = poppins(22, FontWeight.Bold), color = Ink, modifier = Modifier.offset(21.dp, 27.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 65.dp)
        ) {
            weekOf(today).forEach { day ->
                DayChip(day, selected = day == selected, onClick = { selectedDay = day.toEpochDay() })
            }
        }

        if (pickUps.isEmpty()) {
            Text(
                "No pick-ups scheduled",
                style = poppins(14, FontWeight.Medium),
                color = TextMuted,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 70.dp)
            )
        } else {
            ScheduleHours.forEachIndexed { i, hour ->
                val rowTop = 146.dp + 30.dp * i
                Text(hour, style = poppins(12), color = TextMuted, modifier = Modifier.offset(19.dp, rowTop + 3.dp))
                Box(
                    Modifier
                        .offset(y = rowTop + 11.5.dp)
                        .padding(start = 91.dp, end = 19.dp)
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(ScheduleLine, RoundedCornerShape(0.5.dp))
                )
                pickUps.find { it.hourIndex == i }?.let { pickUp ->
                    PickUpChip(
                        "Pick-up Point:  ${pickUp.place}",
                        onPickUpClick,
                        Modifier.offset(y = rowTop).padding(start = 91.dp, end = 19.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DayChip(day: LocalDate, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .size(width = 46.dp, height = 62.dp)
            .clip(shape)
            .clickable(role = Role.Tab, onClick = onClick)
            .semantics { this.selected = selected }
            .then(
                if (selected) Modifier.background(HeaderGreen, shape)
                else Modifier.background(Color.White, shape).border(1.dp, FieldBorder, shape)
            )
            .padding(top = if (selected) 8.dp else 7.dp)
    ) {
        Text(shortDayName(day), style = poppins(12), color = TextMuted)
        Text(
            day.dayOfMonth.toString(),
            style = poppins(15, FontWeight.Bold),
            color = if (selected) Color.White else TextMuted,
            modifier = Modifier.offset(y = 1.dp)
        )
    }
}

@Composable
private fun PickUpChip(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(ChipGreen)
            .clickable(onClick = onClick)
            .padding(start = 8.dp)
    ) {
        Image(painterResource(R.drawable.ic_pin_small), contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text(label, style = poppins(11, FontWeight.Bold), color = Ink, maxLines = 1)
    }
}

/** 08c: the full announcement over a dimmed Home. */
@Composable
private fun AnnouncementPopup(onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    BackHandler(onBack = onDismiss)
    Box(
        modifier
            .fillMaxSize()
            .background(Scrim.copy(alpha = 0.7f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            .padding(top = 110.dp, bottom = 34.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                // 620dp as designed, shrinking (and scrolling) on short screens
                .heightIn(max = 620.dp)
                .fillMaxHeight()
                .card(radius = 28.dp)
                .clip(RoundedCornerShape(28.dp))
                // Swallow taps so only the scrim dismisses
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(top = 29.dp, bottom = 24.dp)
            ) {
                Text("ANNOUNCEMENT", style = poppins(24, FontWeight.Bold), color = Ink)
                Spacer(Modifier.height(6.dp))
                Text("Delay in Garbage Collection for next week", style = poppins(15, FontWeight.Bold), color = Ink, textAlign = TextAlign.Center)
                Text("due to: Typhoon Pepito", style = poppins(12), color = Ink)
                Spacer(Modifier.height(8.dp))
                Image(painterResource(R.drawable.img_typhoon_large), contentDescription = "Typhoon Pepito")
                Spacer(Modifier.height(20.dp))
                Text(
                    AnnouncementBody,
                    style = poppins(12).copy(lineHeight = 18.sp),
                    color = Ink,
                    modifier = Modifier.padding(horizontal = 19.dp)
                )
            }
            Image(
                painter = painterResource(R.drawable.ic_close),
                contentDescription = "Close",
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-15).dp, y = 9.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClick = onDismiss)
            )
        }
    }
}

private val AnnouncementBody = buildAnnotatedString {
    val semiBold = SpanStyle(fontWeight = FontWeight.SemiBold)
    append("Dear ")
    withStyle(semiBold) { append("Trash o’ clock Users") }
    append(",\n")
    append(
        "We regret to inform you that due to the impact of Typhoon Pepito, our garbage collection " +
            "services have been delayed. The safety of our community and our team members is our top " +
            "priority, and the severe weather conditions have made it unsafe to proceed with our scheduled pickups.\n\n"
    )
    append(
        "We apologize for any inconvenience this may cause and appreciate your understanding and " +
            "cooperation during this time. Stay safe, and thank you for your continued support.\n\n"
    )
    append("Sincerely,\n")
    withStyle(semiBold) { append("The Trash o’ clock Team") }
}

@Preview(widthDp = 390, heightDp = 844)
@Composable
private fun HomeScreenPreview() {
    TrashOClockTheme { HomeScreen(contentPadding = PaddingValues(bottom = 80.dp)) }
}
